﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;



namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\liulang\Desktop\GlueInfo.xls";
            DataTable table = ExcelData(path);
            dataGridView1.DataSource = table;
            dataGridView1.Show();
        }
        public DataTable ExcelData(string fileName)
        {
            string strcon = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + fileName + ";" + "Extended Properties=Excel 8.0;";//链接数据源字符串 老版本xls格式
            OleDbConnection oledConnection = new OleDbConnection(strcon);//创建链接数据源对象
            oledConnection.Open();//链接打开
            string StrExcel = "";
            StrExcel = "select * from [sheet1$]";//查询表格指令
            OleDbDataAdapter OledbdataAdapter = null;
            DataSet ds = null;
            OledbdataAdapter = new OleDbDataAdapter(StrExcel, strcon);//创建适配器对象
            ds = new DataSet();//用来存放DataTable
            OledbdataAdapter.Fill(ds);//表示把查询的得到的(DataTable)存放到DataSet里面
            oledConnection.Close();//关闭链接
            DataTable dt = ds.Tables[0];
            return dt;        
        }
    }
}
